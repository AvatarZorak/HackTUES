
desk_x, desk_y = 700, -240 

desk2_x, desk2_y = 1000, -240

desk3_x, desk3_y = 1300, -240

desk4_x, desk4_y = 1350 ,230

desk5_x, desk5_y = 850 ,770

chair_x, chair_y = 690 ,-225

chair2_x, chair2_y = 990 ,-225

chair3_x, chair3_y = 1290 ,-225

wall_down_x, wall_down_y = 605, 1110

wall_down2_x, wall_down2_y =  880, 150

wall_up_x, wall_up_y = 1350 ,-300

wall_up2_x, wall_up2_y = 650 , -610

wall_left_x, wall_left_y = -205, 450

wall_left2_x, wall_left2_y = 305, 900

wall_right_x, wall_right_y = 1500, -500

wall_right2_x, wall_right2_y = 1500, -700

wall_right3_x, wall_right3_y = 2200, 400

shelf_x, shelf_y = 300 ,-300

shelf2_x, shelf2_y = 500 ,200

shelf3_x, shelf3_y = 1000 ,200

shelf4_x, shelf4_y = 550 ,750

shelf5_x, shelf5_y = 1750 ,-220

pot_x, pot_y = 2100 ,1030

pot2_x, pot2_y = 2100 ,-230

table_x, table_y = 2050 ,230

table2_x, table2_y = 2050 ,430

table3_x, table3_y = 2050 ,630

box_x, box_y = 1390 ,-430

box2_x, box2_y = 1290 ,-470

box3_x, box3_y = 1250 ,-400

box4_x, box4_y = 0 ,1000

telescope_x, telescope_y = 150, 990

hologram_x, hologram_y = -90, -580

#level2  ###################################################################

desklvl2_x, desklvl2_y = 900, 350 

wall_ud_x, wall_ud_y = 1070, 270

wall_ud2_x, wall_ud2_y = 1060, 1370

wall_ud3_x, wall_ud3_y = 2320, 570

wall_ud4_x, wall_ud4_y = 2320, 1310

wall_lr_x, wall_lr_y = 460, 350

wall_lr2_x, wall_lr2_y = 1660, 50

wall_lr3_x, wall_lr3_y = 2890, 950

wall_lr4_x, wall_lr4_y = 1660, 1310

shelflvl2_x, shelflvl2_y = 750 ,700

device_x, device_y = 1420 ,450

tablelvl2_x, tablelvl2_y = 850 ,1200

tree_x, tree_y = -500, -200

chairlvl2_x, chairlvl2_y = 870, 1100

chairlvl23_x, chairlvl23_y = 900, 400

tree_x, tree_y = 600, 1200

tree2_x, tree2_y = 2000, 600

tree3_x, tree3_y = 1500, 1250

tree4_x, tree4_y = 2550, 860

tree5_x, tree5_y = 2550, 970

hologramlvl2_x, hologramlvl2_y = 2500, 880
